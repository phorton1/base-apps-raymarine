
Files here come directly from the OpenGL registry:

https://www.opengl.org/registry/api/GL

e.g.: wget https://www.opengl.org/registry/api/GL/glext.h


